# Tagbot App (scaffold)

Este é um scaffold inicial para o app Tagbot.

Requisitos:
- Flutter SDK
Extras adicionados nesta fase:

- `provider` para gerenciamento de estado
- `flutter_reactive_ble` (plugin BLE sugerido)
- `google_fonts` para usar `Orbitron` (título) e `Inter`/sistema para demais textos

Rodar em modo debug:

```bash
flutter pub get
flutter run -d <device>
```

Android (BLE) configuração rápida:

- Garanta `minSdkVersion` >= 21 em `android/app/build.gradle`.
- No `AndroidManifest.xml` adicione permissões de `BLUETOOTH`, `BLUETOOTH_ADMIN`, `ACCESS_FINE_LOCATION` (ou `BLUETOOTH_SCAN/CONNECT` para Android 12+). Você também precisa solicitar permissões em runtime.

Notas:
- A orientação está fixada em modo horizontal.
- A tela de conexão Bluetooth inicial usa um `BluetoothProvider` com método `connectMock()`; substituirei pelo BLE real ao integrar o código antigo.
- Próximo passo: envie o código antigo para eu integrar os protocolos/commands e os assets originais (logos, SVG/TTF).
