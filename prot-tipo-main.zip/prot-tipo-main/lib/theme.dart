import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const Color primaryRed = Color(0xFFB71C1C); // extracted from design (approx)
  static const Color darkBrown = Color(0xFF3E2723);
  static const Color background = Color(0xFFF6F6F6);
}

class AppTextStyles {
  static TextStyle h1() => GoogleFonts.orbitron(fontSize: 28, fontWeight: FontWeight.w700, color: Colors.black);
  static TextStyle h2() => GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.black87);
}
