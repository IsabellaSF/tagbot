import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';

// Importação das telas
import 'screens/splash_nero.dart';
import 'screens/splash_tagbot.dart';
import 'screens/bluetooth_connect.dart';
import 'screens/menu.dart';
import 'screens/digital_page.dart';
import 'screens/gyroscope_page.dart';
import 'screens/joystick_page.dart';
import 'screens/geometry_page.dart';
import 'screens/timer_page.dart';
import 'screens/pwm_page.dart';

// Importação dos Providers e Tema
import 'providers/bluetooth_provider.dart';
import 'theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Força orientação Paisagem
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);

  runApp(TagbotApp());
}

class TagbotApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => BluetoothProvider()),
      ],
      child: MaterialApp(
        title: 'Tagbot',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primaryColor: AppColors.primaryRed,
          scaffoldBackgroundColor: Colors.white,
          textTheme: GoogleFonts.interTextTheme(),
          appBarTheme: AppBarTheme(
            backgroundColor: AppColors.primaryRed,
            titleTextStyle: GoogleFonts.orbitron(
                textStyle: const TextStyle(fontSize: 20, color: Colors.white)),
            iconTheme: const IconThemeData(color: Colors.white),
          ),
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => SplashNero(),
          '/tagbot': (context) => SplashTagbot(),
          '/bluetooth': (context) => BluetoothConnectPage(),
          '/menu': (context) => MenuPage(),
          '/digital': (context) => DigitalPage(),
          '/joystick': (context) => JoystickPage(),
          '/gyroscope': (context) => GyroscopePage(),
          '/geometry': (context) => GeometryPage(),
          '/timer': (context) => TimerPage(),
          '/pwm': (context) => PwmPage(),
        },
      ),
    );
  }
}
