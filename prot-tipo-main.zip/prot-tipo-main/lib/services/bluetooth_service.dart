class BluetoothService {
  // Mock connection for initial scaffold. Replace with real implementation later.
  static Future<bool> connectMock() async {
    await Future.delayed(Duration(seconds: 1));
    return true;
  }
}
