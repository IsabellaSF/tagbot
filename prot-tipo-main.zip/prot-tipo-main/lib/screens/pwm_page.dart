import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/bluetooth_provider.dart';
import '../theme.dart';

class PwmPage extends StatefulWidget {
  @override
  _PwmPageState createState() => _PwmPageState();
}

class _PwmPageState extends State<PwmPage> {
  // Valores PWM (0 a 255)
  double _leftMotorPwm = 0.0;
  double _rightMotorPwm = 0.0;

  // Sincronia: Se true, os dois motores andam juntos
  bool _isLinked = false;

  // Throttling para não inundar o bluetooth
  Timer? _debounce;

  // IDs dos motores no seu código Arduino (ajuste conforme seu robô)
  final int _leftMotorId = 1;
  final int _rightMotorId = 2;

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  void _updateLeft(double val) {
    setState(() {
      _leftMotorPwm = val;
      if (_isLinked) {
        _rightMotorPwm = val; // Espelha o valor se estiver linkado
      }
    });
    _sendPwmCommand();
  }

  void _updateRight(double val) {
    setState(() {
      _rightMotorPwm = val;
      if (_isLinked) {
        _leftMotorPwm = val; // Espelha o valor se estiver linkado
      }
    });
    _sendPwmCommand();
  }

  void _toggleLink() {
    setState(() {
      _isLinked = !_isLinked;
      // Ao ativar o link, iguala as velocidades pela média ou pelo esquerdo
      if (_isLinked) {
        _rightMotorPwm = _leftMotorPwm;
      }
    });
    _sendPwmCommand();
  }

  void _stopAll() {
    setState(() {
      _leftMotorPwm = 0.0;
      _rightMotorPwm = 0.0;
    });
    _sendPwmCommand();
  }

  void _sendPwmCommand() {
    if (_debounce?.isActive ?? false) return;

    _debounce = Timer(const Duration(milliseconds: 50), () async {
      final bt = context.read<BluetoothProvider>();
      if (!bt.connected) return;

      // Protocolo: <PWM:ID_ESQ:VALOR,ID_DIR:VALOR>
      // Exemplo: <PWM:1:255,2:255>
      final cmd =
          '<PWM:$_leftMotorId:${_leftMotorPwm.toInt()},$_rightMotorId:${_rightMotorPwm.toInt()}>';

      try {
        await bt.sendRaw(cmd);
      } catch (_) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Controle de Tração'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset('assets/images/TagBotIcon.png', width: 36),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          children: [
            // --- MOTOR ESQUERDO ---
            Expanded(
              child: _buildMotorControl(
                label: "Motor Esquerdo",
                value: _leftMotorPwm,
                onChanged: _updateLeft,
                color: Colors.red.shade700,
              ),
            ),

            // --- COLUNA CENTRAL (CONTROLES) ---
            SizedBox(
              width: 100,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Botão de Link (Sincronia)
                  GestureDetector(
                    onTap: _toggleLink,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                          color:
                              _isLinked ? AppColors.primaryRed : Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: _isLinked
                                  ? AppColors.primaryRed
                                  : Colors.grey.shade400,
                              width: 2),
                          boxShadow: [
                            if (_isLinked)
                              BoxShadow(
                                  color: AppColors.primaryRed.withOpacity(0.4),
                                  blurRadius: 10,
                                  spreadRadius: 2)
                          ]),
                      child: Icon(
                        _isLinked ? Icons.link : Icons.link_off,
                        color: _isLinked ? Colors.white : Colors.grey,
                        size: 32,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _isLinked ? "TRAVADO" : "LIVRE",
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: _isLinked ? AppColors.primaryRed : Colors.grey),
                  ),

                  const Spacer(),

                  // Botão de Parada de Emergência
                  GestureDetector(
                    onTap: _stopAll,
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.primaryRed)),
                      child: const Icon(Icons.stop,
                          color: AppColors.primaryRed, size: 32),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text("PARAR",
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primaryRed)),
                  const Spacer(),
                ],
              ),
            ),

            // --- MOTOR DIREITO ---
            Expanded(
              child: _buildMotorControl(
                label: "Motor Direito",
                value: _rightMotorPwm,
                onChanged: _updateRight,
                color: Colors.red.shade400,
              ),
            ),
          ],
        ),
      ),
      // Logo NERO
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Image.asset('assets/images/NERoLogo.png', width: 80),
          ],
        ),
      ),
    );
  }

  Widget _buildMotorControl({
    required String label,
    required double value,
    required ValueChanged<double> onChanged,
    required Color color,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
      child: Column(
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey.shade700)),
          const SizedBox(height: 16),

          // Slider Vertical Gigante
          Expanded(
            child: RotatedBox(
              quarterTurns: -1, // Rotaciona para ficar vertical
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 24, // Largura da trilha
                  activeTrackColor: color,
                  inactiveTrackColor: Colors.grey.shade100,
                  thumbColor: Colors.white,
                  thumbShape: const RoundSliderThumbShape(
                      enabledThumbRadius: 18, elevation: 4),
                  overlayColor: color.withOpacity(0.2),
                ),
                child: Slider(
                  value: value,
                  min: 0.0,
                  max: 255.0,
                  divisions: 255,
                  onChanged: onChanged,
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Display do Valor
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              value.toInt().toString(),
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
