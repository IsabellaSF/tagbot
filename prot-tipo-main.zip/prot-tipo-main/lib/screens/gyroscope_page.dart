import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../providers/bluetooth_provider.dart';
import '../theme.dart';

class GyroscopePage extends StatefulWidget {
  @override
  _GyroscopePageState createState() => _GyroscopePageState();
}

class _GyroscopePageState extends State<GyroscopePage> {
  // Dados dos sensores (filtrados)
  double _x = 0;
  double _y = 0;

  // Estado do controlo
  bool _isActive = false;
  double _sensitivity = 2.0; // Ajuste de sensibilidade (1.0 a 5.0)

  // Stream para ouvir o sensor
  StreamSubscription<AccelerometerEvent>? _streamSubscription;

  // Timer para não inundar o bluetooth (Throttling)
  Timer? _debounce;

  @override
  void dispose() {
    _stopListening();
    _debounce?.cancel();
    super.dispose();
  }

  void _toggleControl() {
    if (_isActive) {
      _stopListening();
      // Pequeno delay para garantir que o stop é enviado
      Future.delayed(const Duration(milliseconds: 100), _sendStop);
    } else {
      _startListening();
    }
    setState(() => _isActive = !_isActive);
  }

  void _startListening() {
    // Usamos o acelerómetro porque mede a inclinação (gravidade) de forma absoluta
    _streamSubscription =
        accelerometerEvents.listen((AccelerometerEvent event) {
      if (!mounted) return;

      setState(() {
        // Filtro Low Pass simples para suavizar movimentos bruscos
        // X = Frente/Trás (Aceleração)
        // Y = Esquerda/Direita (Curva)
        // (Nota: A orientação dos eixos pode variar conforme o dispositivo.
        // Assumindo modo paisagem padrão)
        _x = (_x * 0.7) + (event.x * 0.3);
        _y = (_y * 0.7) + (event.y * 0.3);
      });

      _processMovement();
    });
  }

  void _stopListening() {
    _streamSubscription?.cancel();
    _streamSubscription = null;
    setState(() {
      _x = 0;
      _y = 0;
    });
  }

  void _processMovement() {
    // Throttling: Envia no máximo a cada 100ms
    if (_debounce?.isActive ?? false) return;

    _debounce = Timer(const Duration(milliseconds: 100), () async {
      if (!mounted || !_isActive) return;

      final bt = context.read<BluetoothProvider>();
      if (!bt.connected) return;

      // Conversão Matemática:
      // Acelerómetro dá valores de aprox -10 a 10.
      // Precisamos converter para -255 a 255.

      // X negativo costuma ser inclinar para frente em paisagem (depende do device)
      // Ajuste os sinais (-) conforme a física do seu tablet
      int speed = ((-_y) * 25 * _sensitivity).round().clamp(-255, 255);
      int turn = ((-_x) * 25 * _sensitivity).round().clamp(-255, 255);

      // Zona morta (Deadzone) para o robô não andar sozinho se a mesa estiver torta
      if (speed.abs() < 40) speed = 0;
      if (turn.abs() < 40) turn = 0;

      // Protocolo igual ao do Joystick: <0/1/CURVA/VELOCIDADE>
      // Ajuste a ordem X/Y conforme o seu código Arduino espera
      try {
        await bt.sendRaw('<0/1/$turn/$speed>');
      } catch (_) {}
    });
  }

  Future<void> _sendStop() async {
    final bt = context.read<BluetoothProvider>();
    if (bt.connected) {
      try {
        await bt.sendRaw('<0/1/0/0>'); // Comando de paragem
      } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    // Cálculo para mover a "bolha" visualmente na interface
    // Limitamos a 100 pixels de movimento para não sair do círculo
    double bubbleX = (_y * -15).clamp(-100.0, 100.0);
    double bubbleY = (_x * -15).clamp(-100.0, 100.0);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Giroscópio'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset('assets/images/TagBotIcon.png', width: 36),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          children: [
            // --- ESQUERDA: VISUALIZADOR (NÍVEL DE BOLHA) ---
            Expanded(
              flex: 5,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.grey.shade200),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.05), blurRadius: 10)
                  ],
                ),
                child: Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Círculos de referência (Alvo)
                      Container(
                        width: 250,
                        height: 250,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border:
                              Border.all(color: Colors.grey.shade300, width: 1),
                        ),
                      ),
                      Container(
                        width: 150,
                        height: 150,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey.shade50,
                          border:
                              Border.all(color: Colors.grey.shade300, width: 1),
                        ),
                      ),
                      // Linhas de cruz
                      Container(
                          width: 280, height: 1, color: Colors.grey.shade200),
                      Container(
                          width: 1, height: 280, color: Colors.grey.shade200),

                      // A Bolha (Indicador de Inclinação)
                      Transform.translate(
                        offset: Offset(bubbleX, bubbleY),
                        child: Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                              color: _isActive
                                  ? AppColors.primaryRed
                                  : Colors.grey.shade400,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                    color: (_isActive
                                            ? AppColors.primaryRed
                                            : Colors.grey)
                                        .withOpacity(0.4),
                                    blurRadius: 15,
                                    offset: const Offset(0, 5))
                              ]),
                          child: const Center(
                            child:
                                Icon(Icons.control_camera, color: Colors.white),
                          ),
                        ),
                      ),

                      // Texto de Estado
                      Positioned(
                        bottom: 20,
                        child: Text(
                          _isActive ? "CONTROLANDO" : "PARADO",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2,
                              color: _isActive
                                  ? AppColors.primaryRed
                                  : Colors.grey),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(width: 24),

            // --- DIREITA: CONTROLES ---
            Expanded(
              flex: 4,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Card de Sensibilidade
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Sensibilidade",
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            Text("${_sensitivity.toStringAsFixed(1)}x",
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.primaryRed)),
                          ],
                        ),
                        Slider(
                          value: _sensitivity,
                          min: 1.0,
                          max: 5.0,
                          divisions: 8,
                          activeColor: AppColors.primaryRed,
                          onChanged: (val) =>
                              setState(() => _sensitivity = val),
                        ),
                        const Text(
                          "Aumente se o robô estiver muito lento.\nDiminua se estiver muito instável.",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 12, color: Colors.grey),
                        )
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Botão Gigante de Ativar
                  GestureDetector(
                    onTap: _toggleControl,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      width: 140,
                      height: 140,
                      decoration: BoxDecoration(
                          color:
                              _isActive ? Colors.white : AppColors.primaryRed,
                          shape: BoxShape.circle,
                          border:
                              Border.all(color: AppColors.primaryRed, width: 4),
                          boxShadow: [
                            BoxShadow(
                                color: AppColors.primaryRed.withOpacity(0.3),
                                blurRadius: 20,
                                offset: const Offset(0, 10))
                          ]),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            _isActive ? Icons.stop : Icons.power_settings_new,
                            size: 48,
                            color:
                                _isActive ? AppColors.primaryRed : Colors.white,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _isActive ? "PARAR" : "ATIVAR",
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: _isActive
                                    ? AppColors.primaryRed
                                    : Colors.white),
                          )
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),
                  const Text(
                    "Segure o tablet na horizontal\ne incline para mover.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Image.asset('assets/images/NERoLogo.png', width: 80),
          ],
        ),
      ),
    );
  }
}
