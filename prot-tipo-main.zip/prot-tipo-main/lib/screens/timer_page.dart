import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/bluetooth_provider.dart';
import '../theme.dart';

class TimerPage extends StatefulWidget {
  @override
  _TimerPageState createState() => _TimerPageState();
}

class _TimerPageState extends State<TimerPage> {
  // Estado do Timer
  Timer? _timer;
  Duration _duration = const Duration(minutes: 1); // Tempo inicial padrão
  Duration _remaining = const Duration(minutes: 1);
  bool _isRunning = false;

  // Se marcado, envia <STOP> para o robô quando o tempo acabar
  bool _sendStopOnFinish = true;

  @override
  void initState() {
    super.initState();
    _resetTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _resetTimer() {
    _timer?.cancel();
    setState(() {
      _remaining = _duration;
      _isRunning = false;
    });
  }

  void _addTime(int seconds) {
    if (_isRunning) return; // Não altera enquanto roda
    setState(() {
      final newDuration = _duration + Duration(seconds: seconds);
      // Impede tempo negativo ou zero
      if (newDuration.inSeconds > 0) {
        _duration = newDuration;
        _remaining = newDuration;
      }
    });
  }

  void _toggleTimer() {
    if (_isRunning) {
      _timer?.cancel();
      setState(() => _isRunning = false);
    } else {
      setState(() => _isRunning = true);
      _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
        setState(() {
          if (_remaining.inSeconds > 0) {
            _remaining = _remaining - const Duration(seconds: 1);
          } else {
            _timer?.cancel();
            _isRunning = false;
            _onTimerFinished();
          }
        });
      });
    }
  }

  Future<void> _onTimerFinished() async {
    // Toca um som ou vibração (opcional, visual aqui)
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Tempo Esgotado!'),
      backgroundColor: AppColors.primaryRed,
    ));

    if (_sendStopOnFinish) {
      final bt = context.read<BluetoothProvider>();
      if (bt.connected) {
        try {
          await bt.sendRaw('<STOP>');
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('Comando de PARADA enviado ao robô.')));
        } catch (e) {
          // Erro silencioso ou log
        }
      }
    }
  }

  // Formata o tempo MM:SS
  String _formatDuration(Duration d) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(d.inMinutes.remainder(60));
    final seconds = twoDigits(d.inSeconds.remainder(60));
    return "$minutes:$seconds";
  }

  @override
  Widget build(BuildContext context) {
    // Calcula progresso para o círculo (1.0 = cheio, 0.0 = vazio)
    double progress = _duration.inSeconds > 0
        ? _remaining.inSeconds / _duration.inSeconds
        : 0.0;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Temporizador'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset('assets/images/TagBotIcon.png', width: 36),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          children: [
            // --- COLUNA DA ESQUERDA: AJUSTES RÁPIDOS ---
            Expanded(
              flex: 4,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade200),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    )
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Ajustar Tempo",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.black54),
                    ),
                    const SizedBox(height: 20),
                    // Grid de Botões de Ajuste
                    Expanded(
                      child: GridView.count(
                        crossAxisCount: 2,
                        mainAxisSpacing: 16,
                        crossAxisSpacing: 16,
                        childAspectRatio: 1.5,
                        children: [
                          _buildAdjustBtn("+ 1 min", 60),
                          _buildAdjustBtn("+ 10 seg", 10),
                          _buildAdjustBtn("- 1 min", -60),
                          _buildAdjustBtn("- 10 seg", -10),
                        ],
                      ),
                    ),
                    const Divider(),
                    // Opção de Parar Robô
                    SwitchListTile(
                      title: const Text("Parar robô ao fim",
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w600)),
                      activeColor: AppColors.primaryRed,
                      value: _sendStopOnFinish,
                      onChanged: (val) =>
                          setState(() => _sendStopOnFinish = val),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(width: 24),

            // --- COLUNA DA DIREITA: DISPLAY E CONTROLES ---
            Expanded(
              flex: 5,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Círculo de Progresso com Texto no Meio
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 220,
                        height: 220,
                        child: CircularProgressIndicator(
                          value: progress,
                          strokeWidth: 12,
                          backgroundColor: Colors.grey.shade200,
                          color: progress < 0.2
                              ? Colors.red
                              : AppColors.primaryRed,
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _formatDuration(_remaining),
                            style: const TextStyle(
                              fontSize: 56,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                              letterSpacing: 2,
                            ),
                          ),
                          Text(
                            _isRunning ? "RODANDO" : "PAUSADO",
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: _isRunning
                                  ? AppColors.primaryRed
                                  : Colors.grey,
                              letterSpacing: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  const SizedBox(height: 40),

                  // Botões de Controle (Play/Pause/Reset)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Reset
                      GestureDetector(
                        onTap: _resetTimer,
                        child: Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.refresh,
                              size: 28, color: Colors.black54),
                        ),
                      ),
                      const SizedBox(width: 24),
                      // Play/Pause Gigante
                      GestureDetector(
                        onTap: _toggleTimer,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: AppColors.primaryRed,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primaryRed.withOpacity(0.4),
                                blurRadius: 15,
                                offset: const Offset(0, 8),
                              )
                            ],
                          ),
                          child: Icon(
                            _isRunning ? Icons.pause : Icons.play_arrow,
                            size: 40,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      // Logo NERO fixo no canto
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Image.asset('assets/images/NERoLogo.png', width: 80),
          ],
        ),
      ),
    );
  }

  Widget _buildAdjustBtn(String label, int seconds) {
    return ElevatedButton(
      onPressed: _isRunning ? null : () => _addTime(seconds),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.grey.shade100,
        foregroundColor: Colors.black87,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: Colors.grey.shade300),
        ),
      ),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
    );
  }
}
