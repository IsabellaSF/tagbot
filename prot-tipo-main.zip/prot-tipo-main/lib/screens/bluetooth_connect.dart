import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';
import '../providers/bluetooth_provider.dart';

class BluetoothConnectPage extends StatefulWidget {
  @override
  _BluetoothConnectPageState createState() => _BluetoothConnectPageState();
}

class _BluetoothConnectPageState extends State<BluetoothConnectPage> {
  @override
  void initState() {
    super.initState();
    // Tenta iniciar o scan, mas não bloqueia se falhar (ex: sem permissão/bluetooth desligado)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      try {
        context.read<BluetoothProvider>().startScan();
      } catch (e) {
        print("Scan não iniciado (Modo Offline/Sem Permissão): $e");
      }
    });
  }

  Color _avatarColor(int index) {
    final colors = [
      Colors.red.shade100,
      Colors.red.shade700,
      Colors.red.shade200
    ];
    return colors[index % colors.length];
  }

  Future<void> _connectToDevice(BuildContext context, String deviceId) async {
    final bt = context.read<BluetoothProvider>();
    try {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Conectando... aguarde.')),
      );

      final ok = await bt.connect(deviceId);

      if (ok) {
        Navigator.of(context).pushReplacementNamed('/menu');
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Falha ao conectar')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Erro: ${e.toString()}')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<BluetoothProvider>(
      builder: (context, bt, child) {
        return Scaffold(
          backgroundColor: Colors.black,
          body: SafeArea(
            child: Stack(
              children: [
                // Ícone TagBot no canto
                Positioned(
                  left: 16,
                  top: 16,
                  child: CircleAvatar(
                    backgroundColor: Colors.transparent,
                    radius: 22,
                    child: Image.asset(
                      'assets/images/TagBotIcon.png',
                      width: 36,
                      height: 36,
                      errorBuilder: (c, o, s) =>
                          const Icon(Icons.android, color: Colors.white),
                    ),
                  ),
                ),

                Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 920),
                    child: Card(
                      elevation: 6,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6)),
                      margin: const EdgeInsets.symmetric(horizontal: 24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Cabeçalho
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 18),
                            child: Row(
                              children: [
                                const Icon(Icons.bluetooth, size: 28),
                                const Expanded(
                                  child: Center(
                                    child: Text(
                                      'Conecte-se ao tagbot pelo Bluetooth',
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.w700),
                                    ),
                                  ),
                                ),
                                // Botão de Recarregar
                                Container(
                                  width: 44,
                                  height: 44,
                                  decoration: BoxDecoration(
                                    color: Colors.red.shade200,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.refresh),
                                    tooltip: 'Reiniciar Scan',
                                    onPressed: () {
                                      try {
                                        bt.startScan();
                                      } catch (_) {}
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),

                          // Lista de Dispositivos
                          Container(
                            color: Colors.grey.shade100,
                            constraints: const BoxConstraints(maxHeight: 260),
                            child: bt.devices.isEmpty
                                ? const Center(
                                    child: Padding(
                                      padding: EdgeInsets.all(20.0),
                                      child: Text(
                                        "Nenhum dispositivo encontrado.\n(Verifique GPS e Bluetooth)",
                                        textAlign: TextAlign.center,
                                      ),
                                    ),
                                  )
                                : ListView.separated(
                                    shrinkWrap: true,
                                    itemCount: bt.devices.length,
                                    separatorBuilder: (_, __) =>
                                        const Divider(height: 1),
                                    itemBuilder: (context, index) {
                                      final dev = bt.devices[index];
                                      final isConnected = bt.connected &&
                                          bt.currentDeviceId == dev.id;

                                      return ListTile(
                                        leading: CircleAvatar(
                                          backgroundColor: _avatarColor(index),
                                          child: Text(
                                              dev.name.isNotEmpty
                                                  ? dev.name[0]
                                                  : '?',
                                              style: const TextStyle(
                                                  color: Colors.white)),
                                        ),
                                        title: Text(dev.name.isNotEmpty
                                            ? dev.name
                                            : "Sem nome"),
                                        subtitle: Text(dev.id),
                                        onTap: () =>
                                            _connectToDevice(context, dev.id),
                                        trailing: isConnected
                                            ? const Icon(Icons.check_circle,
                                                color: Colors.green)
                                            : null,
                                      );
                                    },
                                  ),
                          ),

                          const SizedBox(height: 12),
                          // Rodapé do Card
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16.0, vertical: 12),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                // Feedback visual de conexão
                                Text(
                                  bt.connected ? "CONECTADO" : "DESCONECTADO",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: bt.connected
                                          ? Colors.green
                                          : Colors.red,
                                      fontSize: 12),
                                ),

                                // BOTÃO MODIFICADO: Sempre Habilitado
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.black87),
                                  // Agora chama a navegação direto, sem verificar conexão
                                  onPressed: () {
                                    Navigator.of(context)
                                        .pushReplacementNamed('/menu');
                                  },
                                  child: const Text('Ir para o Menu'),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
