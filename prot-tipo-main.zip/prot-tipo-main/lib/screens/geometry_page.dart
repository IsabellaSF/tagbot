import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/bluetooth_provider.dart';
import '../theme.dart';

class GeometryPage extends StatefulWidget {
  @override
  _GeometryPageState createState() => _GeometryPageState();
}

class _GeometryPageState extends State<GeometryPage> {
  // Lista da sequência de formas para enviar
  final List<Map<String, dynamic>> _sequence = [];
  bool _sending = false;
  double _scale = 1.0; // Tamanho da forma (1.0 = 100%)

  // Definição das formas disponíveis
  final List<Map<String, dynamic>> _availableShapes = [
    {'id': 'SQUARE', 'label': 'Quadrado', 'icon': Icons.crop_square},
    {'id': 'TRIANGLE', 'label': 'Triângulo', 'icon': Icons.change_history},
    {'id': 'CIRCLE', 'label': 'Círculo', 'icon': Icons.circle_outlined},
    {'id': 'STAR', 'label': 'Estrela', 'icon': Icons.star_border},
    {'id': 'SPIRAL', 'label': 'Espiral', 'icon': Icons.gesture},
    {'id': 'ZIGZAG', 'label': 'ZigZag', 'icon': Icons.show_chart},
  ];

  void _addShape(Map<String, dynamic> shape) {
    setState(() {
      _sequence.add({
        'id': shape['id'],
        'label': shape['label'],
        'scale': _scale, // Salva o tamanho configurado no momento
      });
    });
  }

  void _removeLast() {
    if (_sequence.isNotEmpty) {
      setState(() => _sequence.removeLast());
    }
  }

  void _clearSequence() {
    setState(() => _sequence.clear());
  }

  Future<void> _sendGeometry() async {
    final bt = context.read<BluetoothProvider>();

    if (!bt.connected) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Conecte-se ao robô primeiro')));
      return;
    }

    if (_sequence.isEmpty) return;

    setState(() => _sending = true);

    try {
      // Monta o comando. Ex: <GEO:SQUARE:1.0,TRIANGLE:0.5>
      List<String> commands = _sequence.map((item) {
        return '${item['id']}:${item['scale'].toStringAsFixed(1)}';
      }).toList();

      final String payload = '<GEO:${commands.join(',')}>';

      await bt.sendRaw(payload);

      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Sequência enviada!')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Erro: $e')));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Geometria'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset('assets/images/TagBotIcon.png', width: 36),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          children: [
            // --- ESQUERDA: GRID DE FORMAS ---
            Expanded(
              flex: 5,
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.2,
                ),
                itemCount: _availableShapes.length,
                itemBuilder: (context, index) {
                  final shape = _availableShapes[index];
                  return GestureDetector(
                    onTap: () => _addShape(shape),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4))
                        ],
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(shape['icon'],
                              size: 40, color: AppColors.primaryRed),
                          const SizedBox(height: 8),
                          Text(shape['label'],
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black87)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(width: 24),

            // --- DIREITA: LISTA E CONTROLES ---
            Expanded(
              flex: 4,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Caixa da Sequência
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border:
                            Border.all(color: AppColors.primaryRed, width: 2),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Sequência:',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16)),
                              IconButton(
                                icon: const Icon(Icons.delete_sweep,
                                    color: Colors.grey),
                                onPressed: _clearSequence,
                                tooltip: "Limpar tudo",
                              )
                            ],
                          ),
                          const Divider(),
                          Expanded(
                            child: _sequence.isEmpty
                                ? Center(
                                    child: Text(
                                        'Toque nas formas para adicionar',
                                        style: TextStyle(
                                            color: Colors.grey.shade400)))
                                : ListView.separated(
                                    itemCount: _sequence.length,
                                    separatorBuilder: (_, __) =>
                                        const SizedBox(height: 8),
                                    itemBuilder: (context, index) {
                                      final item = _sequence[index];
                                      return Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                            color: Colors.grey.shade100,
                                            borderRadius:
                                                BorderRadius.circular(8)),
                                        child: Row(
                                          children: [
                                            Text(
                                                '${index + 1}. ${item['label']}',
                                                style: const TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold)),
                                            const Spacer(),
                                            Text(
                                                'Escala: ${item['scale'].toStringAsFixed(1)}x',
                                                style: const TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.grey)),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Controle de Tamanho (Slider)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Tamanho da Forma"),
                            Text("${(_scale * 100).toInt()}%",
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.primaryRed)),
                          ],
                        ),
                        Slider(
                          value: _scale,
                          min: 0.5,
                          max: 2.0,
                          divisions: 6,
                          activeColor: AppColors.primaryRed,
                          onChanged: (v) => setState(() => _scale = v),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Botões de Ação
                  Row(
                    children: [
                      GestureDetector(
                        onTap: _removeLast,
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              shape: BoxShape.circle),
                          child: const Icon(Icons.backspace,
                              color: Colors.black54),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _sending ? null : _sendGeometry,
                          icon: _sending
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                      color: Colors.white, strokeWidth: 2))
                              : const Icon(Icons.play_arrow),
                          label: Text(_sending ? 'ENVIANDO...' : 'DESENHAR'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primaryRed,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
      // Logo NERO fixo no canto
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Image.asset('assets/images/NERoLogo.png', width: 80),
          ],
        ),
      ),
    );
  }
}
