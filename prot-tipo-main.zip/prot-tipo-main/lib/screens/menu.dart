import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme.dart';

class MenuPage extends StatelessWidget {
  // Lista de itens do menu com ícones apropriados
  final List<Map<String, dynamic>> items = [
    {'label': 'Digital', 'route': '/digital', 'icon': Icons.touch_app},
    {'label': 'Geometria', 'route': '/geometry', 'icon': Icons.change_history},
    {'label': 'Joystick', 'route': '/joystick', 'icon': Icons.gamepad},
    {'label': 'Temporizador', 'route': '/timer', 'icon': Icons.timer},
    {
      'label': 'Giroscópio',
      'route': '/gyroscope',
      'icon': Icons.screen_rotation
    },
    {'label': 'Ajuste PWM', 'route': '/pwm', 'icon': Icons.tune},
  ];

  void _showHelp(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Como usar o Tagbot',
            style: TextStyle(fontWeight: FontWeight.bold)),
        content: const Text(
          '1. Conecte-se pelo menu Bluetooth.\n'
          '2. Escolha um modo de controle.\n'
          '3. Use os controles na tela para comandar o robô.',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Fechar')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 1. CORREÇÃO DE COR: Fundo preto conforme solicitado
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            // Ícone TagBot (Topo Esquerdo)
            Positioned(
              left: 20,
              top: 20,
              child: CircleAvatar(
                backgroundColor: Colors.transparent,
                radius: 24,
                child: Image.asset(
                  'assets/images/TagBotIcon.png',
                  width: 48,
                  errorBuilder: (c, o, s) =>
                      const Icon(Icons.smart_toy, color: AppColors.primaryRed),
                ),
              ),
            ),

            // Conteúdo Central (Menu)
            Center(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 40.0, vertical: 20),
                // 2. CORREÇÃO DE RESPONSIVIDADE: FittedBox escala tudo para caber na tela sem overflow
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: SizedBox(
                    width: 900, // Largura base de referência para o layout
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Grid de Botões
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: items.length,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3, // 3 colunas
                            childAspectRatio:
                                2.2, // Botões retangulares (Mais largos que altos)
                            crossAxisSpacing: 20,
                            mainAxisSpacing: 20,
                          ),
                          itemBuilder: (context, index) {
                            return _buildMenuButton(context, items[index]);
                          },
                        ),

                        const SizedBox(height: 40),

                        // Ícones Sociais e Ajuda
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          decoration: BoxDecoration(
                              // Fundo branco para destacar os ícones sociais no fundo preto
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(50),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.white.withOpacity(0.1),
                                    blurRadius: 10)
                              ]),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _buildSocialIcon(
                                  'assets/images/InstagramIcon.png'),
                              const SizedBox(width: 24),
                              _buildSocialIcon('assets/images/GithubIcon.png'),
                              const SizedBox(width: 24),
                              _buildSocialIcon('assets/images/YouTubeIcon.png'),
                              const SizedBox(width: 24),
                              IconButton(
                                icon: const Icon(Icons.help_outline,
                                    color: Colors.black54),
                                tooltip: "Ajuda",
                                onPressed: () => _showHelp(context),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

            // Logo NERO (Canto Inferior Direito)
            Positioned(
              right: 20,
              bottom: 20,
              child: Image.asset(
                'assets/images/NERoLogo.png',
                width: 80,
                errorBuilder: (c, o, s) => const Text("NERO",
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.white70)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget Auxiliar para os Botões Vermelhos
  Widget _buildMenuButton(BuildContext context, Map<String, dynamic> item) {
    return ElevatedButton(
      onPressed: () {
        Navigator.pushNamed(context, item['route']);
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primaryRed,
        foregroundColor: Colors.white,
        elevation: 4,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(item['icon'], size: 28),
          const SizedBox(width: 12),
          Text(
            item['label'].toString().toUpperCase(),
            style: GoogleFonts.orbitron(
              fontSize: 16, // Tamanho da fonte ajustado
              fontWeight: FontWeight.bold,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialIcon(String assetPath) {
    return Image.asset(
      assetPath,
      width: 24,
      color: Colors.black54, // Deixa os ícones cinza para ficar elegante
      errorBuilder: (c, o, s) =>
          const Icon(Icons.link, size: 24, color: Colors.grey),
    );
  }
}
