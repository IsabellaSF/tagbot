import 'package:flutter/material.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import '../providers/bluetooth_provider.dart';
import '../theme.dart';

class JoystickPage extends StatefulWidget {
  @override
  _JoystickPageState createState() => _JoystickPageState();
}

class _JoystickPageState extends State<JoystickPage> {
  double _knobX = 0.0;
  double _knobY = 0.0;

  Timer? _rotateTimer;
  Timer? _joystickThrottle;

  @override
  void dispose() {
    _rotateTimer?.cancel();
    _joystickThrottle?.cancel();
    super.dispose();
  }

  void _sendMove() {
    if (_joystickThrottle != null && _joystickThrottle!.isActive) return;

    _joystickThrottle = Timer(const Duration(milliseconds: 50), () async {
      if (!mounted) return;

      final bt = context.read<BluetoothProvider>();
      if (!bt.connected) return;

      final int x = (_knobX * 255).round();
      final int y = (-_knobY * 255).round();

      try {
        await bt.sendRaw('<0/1/$x/$y>');
      } catch (_) {}
    });
  }

  void _startRotate(int dir) {
    if (_rotateTimer != null) return;
    _sendRotateCommand(dir);
    _rotateTimer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      _sendRotateCommand(dir);
    });
  }

  Future<void> _sendRotateCommand(int dir) async {
    if (!mounted) return;
    final bt = context.read<BluetoothProvider>();
    if (!bt.connected) return;
    try {
      await bt.sendRaw('<1/2/$dir/0>');
    } catch (_) {}
  }

  void _stopRotate() {
    _rotateTimer?.cancel();
    _rotateTimer = null;
  }

  @override
  Widget build(BuildContext context) {
    // Escuta mudanças de conexão para atualizar a cor
    final isConnected =
        context.select<BluetoothProvider, bool>((p) => p.connected);

    // Cor dinâmica: Vermelho se conectado, Cinza se desconectado
    final Color activeColor = isConnected ? AppColors.primaryRed : Colors.grey;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Joystick'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          // Indicador de conexão na AppBar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Icon(
              isConnected
                  ? Icons.bluetooth_connected
                  : Icons.bluetooth_disabled,
              color: activeColor,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Image.asset('assets/images/TagBotIcon.png', width: 36),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Stack(
          children: [
            // Área do Joystick
            Align(
              alignment: Alignment.centerLeft,
              child: _buildJoystick(activeColor, isConnected),
            ),

            // Botões de Rotação
            Align(
              alignment: Alignment.centerRight,
              child: _buildRotateButtons(activeColor, isConnected),
            ),

            // Logo Nero
            Positioned(
              right: 24,
              bottom: 24,
              child: Image.asset('assets/images/NERoLogo.png', width: 80),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildJoystick(Color color, bool isConnected) {
    return GestureDetector(
      onPanUpdate: (details) {
        // Só permite mover se estiver conectado (Opcional, se quiser travar a UI)
        // if (!isConnected) return;

        final dx = details.delta.dx;
        final dy = details.delta.dy;

        setState(() {
          _knobX = (_knobX + dx / 100).clamp(-1.0, 1.0);
          _knobY = (_knobY + dy / 100).clamp(-1.0, 1.0);
        });
        _sendMove();
      },
      onPanEnd: (_) {
        setState(() {
          _knobX = 0.0;
          _knobY = 0.0;
        });
        _sendMove();
      },
      child: Container(
        width: 240,
        height: 240,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color.withOpacity(0.15),
          border: Border.all(
              color: isConnected ? Colors.black54 : Colors.grey.shade300,
              width: 2),
        ),
        child: Stack(
          children: [
            Positioned(
              left: 120 + _knobX * 70 - 24,
              top: 120 + _knobY * 70 - 24,
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color, // Cor muda conforme conexão
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 8,
                      offset: const Offset(4, 6),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRotateButtons(Color color, bool isConnected) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        _rotateButton(Icons.rotate_left, 4, color),
        const SizedBox(height: 16),
        _rotateButton(Icons.rotate_right, 3, color),
      ],
    );
  }

  Widget _rotateButton(IconData icon, int dir, Color color) {
    return GestureDetector(
      onTapDown: (_) => _startRotate(dir),
      onTapUp: (_) => _stopRotate(),
      onTapCancel: () => _stopRotate(),
      child: Container(
        width: 64,
        height: 64,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: color,
            width: 2,
          ),
        ),
        child: Icon(
          icon,
          color: color,
        ),
      ),
    );
  }
}
