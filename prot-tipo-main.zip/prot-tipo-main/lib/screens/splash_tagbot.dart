import 'package:flutter/material.dart';

class SplashTagbot extends StatefulWidget {
  @override
  _SplashTagbotState createState() => _SplashTagbotState();
}

class _SplashTagbotState extends State<SplashTagbot> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 1200), () {
      Navigator.of(context).pushReplacementNamed('/bluetooth');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final logoSize = constraints.maxHeight * 0.45;
                return ConstrainedBox(
                  constraints:
                      BoxConstraints(maxHeight: logoSize, maxWidth: logoSize),
                  child: Image.asset(
                    'assets/images/TagBotIcon.png',
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) => Container(
                      width: logoSize,
                      height: logoSize,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.red[700],
                      ),
                      child: Center(
                        child: Text(
                          'TAGBOT',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
