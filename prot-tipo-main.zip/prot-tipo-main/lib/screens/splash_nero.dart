import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

class SplashNero extends StatefulWidget {
  @override
  _SplashNeroState createState() => _SplashNeroState();
}

class _SplashNeroState extends State<SplashNero> {
  @override
  void initState() {
    super.initState();
    _initApp();
  }

  Future<void> _initApp() async {
    // 1. Garante o tempo mínimo de exibição da marca (1.4s conforme seu código)
    // Usamos Future.wait para garantir que o tempo passe MESMO se a permissão for rápida
    await Future.wait([
      Future.delayed(const Duration(milliseconds: 1400)),
      _requestPermissions(), // Pede permissão enquanto a logo aparece
    ]);

    // 2. Navega para a próxima tela
    if (mounted) {
      Navigator.of(context).pushReplacementNamed('/tagbot');
    }
  }

  Future<void> _requestPermissions() async {
    // Apenas no Android precisamos pedir isso explicitamente em runtime
    if (Platform.isAndroid) {
      await [
        Permission.location,
        Permission.bluetoothScan,
        Permission.bluetoothConnect,
        Permission.bluetooth,
      ].request();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final logoWidth = constraints.maxWidth * 0.7;
                return ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: logoWidth),
                  child: Image.asset(
                    'assets/images/NERoSplash.png',
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) => const Text(
                      'nero',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 6,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
