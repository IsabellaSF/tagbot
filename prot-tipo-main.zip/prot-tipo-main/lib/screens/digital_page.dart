import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart'; // Import necessário para a fonte do menu
import '../providers/bluetooth_provider.dart';
import '../theme.dart';

class DigitalPage extends StatefulWidget {
  @override
  _DigitalPageState createState() => _DigitalPageState();
}

class _DigitalPageState extends State<DigitalPage> {
  List<String> _sequence = [];
  bool _playing = false;

  // --- LISTA DE NAVEGAÇÃO (Copie isto para outras páginas) ---
  final List<Map<String, dynamic>> _menuItems = [
    {
      'label': 'Menu Principal',
      'route': '/menu',
      'icon': Icons.grid_view
    }, // Adicionei volta para o menu
    {'label': 'Digital', 'route': '/digital', 'icon': Icons.touch_app},
    {'label': 'Geometria', 'route': '/geometry', 'icon': Icons.change_history},
    {'label': 'Joystick', 'route': '/joystick', 'icon': Icons.gamepad},
    {'label': 'Temporizador', 'route': '/timer', 'icon': Icons.timer},
    {
      'label': 'Giroscópio',
      'route': '/gyroscope',
      'icon': Icons.screen_rotation
    },
    {'label': 'Ajuste PWM', 'route': '/pwm', 'icon': Icons.tune},
  ];

  void _addCommand(String cmd) {
    setState(() {
      _sequence.add(cmd);
    });
  }

  void _removeLast() {
    if (_sequence.isNotEmpty) {
      setState(() => _sequence.removeLast());
    }
  }

  Future<void> _playSequence() async {
    final bt = context.read<BluetoothProvider>();

    if (!bt.connected) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Conecte-se ao robô primeiro')));
      return;
    }

    setState(() => _playing = true);

    try {
      final String payload = '<SEQ:${_sequence.join(',')}>';
      await bt.sendRaw(payload);

      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Sequência enviada')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Erro: ${e.toString()}')));
      }
    } finally {
      if (mounted) {
        setState(() => _playing = false);
      }
    }
  }

  // --- WIDGET DO DRAWER (Copie este método se quiser o código mais limpo) ---
  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: Container(
        color: Colors.grey[900], // Fundo escuro igual ao do menu
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: AppColors.primaryRed),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Image.asset('assets/images/TagBotIcon.png', width: 60),
                  const SizedBox(height: 10),
                  Text('Navegação',
                      style: GoogleFonts.orbitron(
                          color: Colors.white, fontSize: 20)),
                ],
              ),
            ),
            ..._menuItems.map((item) => ListTile(
                  leading: Icon(item['icon'], color: Colors.white70),
                  title: Text(item['label'],
                      style: const TextStyle(color: Colors.white)),
                  onTap: () {
                    Navigator.pop(context); // Fecha o menu lateral
                    // Se for a mesma página, não faz nada
                    if (ModalRoute.of(context)?.settings.name == item['route'])
                      return;

                    // Navega para a nova rota
                    Navigator.pushReplacementNamed(context, item['route']);
                  },
                )),
            const Divider(color: Colors.grey),
            ListTile(
              leading: const Icon(Icons.bluetooth, color: Colors.white70),
              title: const Text('Bluetooth',
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/bluetooth');
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDPad() {
    return Container(
      width: 220,
      height: 220,
      decoration: const BoxDecoration(
          color: AppColors.primaryRed, shape: BoxShape.circle),
      child: Center(
        child: Stack(
          children: [
            Positioned(
              top: 18,
              left: 86,
              right: 86,
              child: IconButton(
                icon: const Icon(Icons.arrow_drop_up,
                    size: 36, color: Colors.black87),
                onPressed: () => _addCommand('UP'),
              ),
            ),
            Positioned(
              bottom: 18,
              left: 86,
              right: 86,
              child: IconButton(
                icon: const Icon(Icons.arrow_drop_down,
                    size: 36, color: Colors.black87),
                onPressed: () => _addCommand('DOWN'),
              ),
            ),
            Positioned(
              left: 18,
              top: 86,
              bottom: 86,
              child: IconButton(
                icon: const Icon(Icons.arrow_left,
                    size: 36, color: Colors.black87),
                onPressed: () => _addCommand('LEFT'),
              ),
            ),
            Positioned(
              right: 18,
              top: 86,
              bottom: 86,
              child: IconButton(
                icon: const Icon(Icons.arrow_right,
                    size: 36, color: Colors.black87),
                onPressed: () => _addCommand('RIGHT'),
              ),
            ),
            Positioned(
              left: 86,
              top: 86,
              child: GestureDetector(
                onTap: _removeLast,
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                      color: Colors.grey[200], shape: BoxShape.circle),
                  child: const Icon(Icons.close, color: Colors.black54),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      // --- APP BAR PADRONIZADA ---
      appBar: AppBar(
        // Mantive branca para combinar com o design da Digital Page,
        // mas o ícone do menu (hamburger) aparecerá automaticamente por causa do drawer.
        title: const Text('Digital'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset('assets/images/TagBotIcon.png', width: 36),
          )
        ],
      ),
      // --- DRAWER ADICIONADO AQUI ---
      drawer: _buildDrawer(context),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // D-Pad na Esquerda
            _buildDPad(),
            const SizedBox(width: 28),

            // Área central
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 120,
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.primaryRed, width: 2),
                    ),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: _sequence.isEmpty
                            ? [
                                const Text('Sem comandos',
                                    style: TextStyle(color: Colors.black54))
                              ]
                            : _sequence
                                .map((s) => Container(
                                      margin: const EdgeInsets.symmetric(
                                          horizontal: 8),
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                          color: Colors.grey[200],
                                          borderRadius:
                                              BorderRadius.circular(6)),
                                      child: Text(s),
                                    ))
                                .toList(),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: _playing ? null : _playSequence,
                        style: ElevatedButton.styleFrom(
                            shape: const CircleBorder(),
                            padding: const EdgeInsets.all(18),
                            backgroundColor: Colors.white),
                        child:
                            const Icon(Icons.play_arrow, color: Colors.black87),
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton(
                        onPressed: _playing
                            ? () => setState(() => _playing = false)
                            : null,
                        style: ElevatedButton.styleFrom(
                            shape: const CircleBorder(),
                            padding: const EdgeInsets.all(18),
                            backgroundColor: Colors.white),
                        child: const Icon(Icons.pause, color: Colors.black87),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Direita: Logo NERO
            const SizedBox(width: 24),
            Column(
              children: [
                const Spacer(),
                Image.asset('assets/images/NERoLogo.png', width: 80),
              ],
            )
          ],
        ),
      ),
    );
  }
}
