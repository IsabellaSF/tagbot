import 'package:flutter/material.dart';

/// Classe Sequence
/// Atualizada para usar ChangeNotifier (compatível com o pacote 'provider' do pubspec.yaml).
/// Isso permite que a UI "escute" alterações na lista de comandos e atualize sozinha.
class Sequence extends ChangeNotifier {
  // Mantivemos a estrutura de lista de listas [action, value]
  final List<List<double>> data = [];

  // Método para adicionar valor à sequência
  void add(double action, double value) {
    data.add([action, value]);
    notifyListeners(); // Avisa aos widgets que a lista mudou
  }

  // Método para remover o último elemento
  void removeLast() {
    if (data.isNotEmpty) {
      data.removeLast();
      notifyListeners(); // Avisa aos widgets que a lista mudou
    }
  }

  // Método para limpar a sequência
  void clear() {
    if (data.isNotEmpty) {
      data.clear();
      notifyListeners(); // Avisa aos widgets que a lista mudou
    }
  }

  // Gets auxiliares para verificar estado
  bool get isNotEmpty => data.isNotEmpty;
  bool get isEmpty => data.isEmpty;
  
  // Getter para acessar os dados de forma segura (opcional, mas boa prática)
  List<List<double>> get currentData => List.unmodifiable(data);
}

/// Widget SequenceContent
/// Responsável por exibir a fila de comandos visualmente.
class SequenceContent extends StatelessWidget {
  final List<List<double>> data; // Recebe os dados da Sequence
  final String subscriptUnit;    // Ex: "cm", "s", "°"
  final double widgetSpace;
  final double widgetSize;
  final double subscriptSpace;
  final double subscriptTextSize;
  final double subscriptOffset;
  final int decimalPlaces;
  final Color widgetColor;
  final VoidCallback onTap;
  final IconData Function(double?) getIconForState;
  final ScrollController scrollController;

  const SequenceContent({
    Key? key,
    required this.data, // Pode ser passado via Consumer<Sequence> no widget pai
    required this.subscriptUnit,
    this.widgetSpace = 10.0,      // Valores padrão adicionados para facilitar uso
    this.widgetSize = 30.0,
    this.subscriptSpace = 2.0,
    this.subscriptTextSize = 12.0,
    this.subscriptOffset = 5.0,
    this.decimalPlaces = 0,
    this.widgetColor = Colors.black,
    required this.onTap,
    required this.getIconForState,
    required this.scrollController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ListView.builder(
        controller: scrollController,
        scrollDirection: Axis.horizontal,
        itemCount: data.length,
        itemBuilder: (context, index) {
          // Extrai os dados do par [ação, valor]
          List<double> item = data[index];
          double? state = item[0];      // Ação (Frente, Trás, etc)
          double value = item[1];       // Valor (Distância, Tempo)

          IconData iconData = getIconForState(state);

          return Row(
            mainAxisSize: MainAxisSize.min, // Ocupa apenas o espaço necessário
            children: [
              // Adiciona espaço entre itens, exceto antes do primeiro
              if (index > 0) SizedBox(width: widgetSpace),
              
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Ícone da ação
                  Icon(
                    iconData, 
                    color: widgetColor, 
                    size: widgetSize
                  ),
                  
                  SizedBox(width: subscriptSpace),
                  
                  // Texto do valor (com deslocamento e fonte personalizada)
                  Transform.translate(
                    offset: Offset(0, subscriptOffset),
                    child: Text(
                      '${value.toStringAsFixed(decimalPlaces)}$subscriptUnit',
                      style: TextStyle(
                        fontFamily: 'Comic', // Usando a fonte do pubspec.yaml
                        fontSize: subscriptTextSize,
                        color: widgetColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }
}