import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';

class BluetoothProvider with ChangeNotifier {
  final FlutterReactiveBle _ble = FlutterReactiveBle();
  StreamSubscription<DiscoveredDevice>? _scanSub;
  StreamSubscription<ConnectionStateUpdate>? _connectionSub;
  QualifiedCharacteristic? _connectedChar;
  bool _connected = false;
  String? _deviceId;

  // Lista interna de dispositivos para persistência visual
  final List<DiscoveredDevice> _devices = [];
  List<DiscoveredDevice> get devices => List.unmodifiable(_devices);

  bool get connected => _connected;
  String? get currentDeviceId => _deviceId;

  /// Stream de dispositivos descobertos (sem filtro de serviço inicial).
  Stream<DiscoveredDevice> scanForDevices() =>
      _ble.scanForDevices(withServices: []);

  /// Inicia o scan e preenche a lista interna '_devices'
  void startScan() {
    _devices.clear();
    notifyListeners();

    _scanSub?.cancel();
    _scanSub = _ble.scanForDevices(withServices: []).listen((device) {
      final index = _devices.indexWhere((d) => d.id == device.id);
      if (index >= 0) {
        _devices[index] = device;
      } else {
        if (device.name.isNotEmpty) {
          _devices.add(device);
        }
      }
      notifyListeners();
    }, onError: (e) {
      if (kDebugMode) print('Erro no scan: $e');
    });
  }

  void stopScan() {
    _scanSub?.cancel();
    _scanSub = null;
  }

  /// Conecta a um dispositivo e tenta descobrir serviços automaticamente
  Future<bool> connect(String deviceId,
      {String? serviceUuid,
      String? charUuid,
      Duration timeout = const Duration(seconds: 10)}) async {
    await disconnect();
    _deviceId = deviceId;

    final completer = Completer<bool>();

    _connectionSub = _ble
        .connectToDevice(id: deviceId, connectionTimeout: timeout)
        .listen((update) async {
      if (update.connectionState == DeviceConnectionState.connected) {
        _connected = true;

        // Tenta descobrir característica de escrita
        if (serviceUuid != null && charUuid != null) {
          _connectedChar = QualifiedCharacteristic(
            serviceId: Uuid.parse(serviceUuid),
            characteristicId: Uuid.parse(charUuid),
            deviceId: deviceId,
          );
        } else {
          try {
            await _discoverServices(deviceId);
          } catch (e) {
            if (kDebugMode) print('Falha na descoberta de serviços: $e');
          }
        }

        notifyListeners();
        if (!completer.isCompleted) completer.complete(true);
      } else if (update.connectionState == DeviceConnectionState.disconnected) {
        _connected = false;
        notifyListeners();
        if (!completer.isCompleted) completer.complete(false);
      }
    }, onError: (e) {
      _connected = false;
      notifyListeners();
      if (!completer.isCompleted) completer.complete(false);
    });

    return completer.future;
  }

  Future<void> _discoverServices(String deviceId) async {
    final services = await _ble.discoverServices(deviceId);
    for (final s in services) {
      for (final c in s.characteristics) {
        if (c.isWritableWithResponse || c.isWritableWithoutResponse) {
          _connectedChar = QualifiedCharacteristic(
            serviceId: s.serviceId,
            characteristicId: c.characteristicId,
            deviceId: deviceId,
          );
          return; // Para no primeiro que encontrar
        }
      }
    }
  }

  /// Envia uma lista de comandos sequenciais
  Future<void> sendSequence(List<String> seq) async {
    if (!_connected) throw Exception('Não conectado');
    final payload = '<SEQ:${seq.join(',')}>';
    await writeString(payload);
    if (kDebugMode) print('Sequence sent: $payload');
  }

  /// Envia uma string crua
  Future<void> sendRaw(String msg) async {
    if (!_connected) throw Exception('Não conectado');
    await writeString(msg);
    if (kDebugMode) print('Raw sent: $msg');
  }

  Future<void> writeString(String msg, {bool withResponse = false}) async {
    if (_connectedChar == null)
      throw Exception('Nenhuma característica de escrita configurada');

    final bytes = utf8.encode(msg);
    try {
      if (withResponse) {
        await _ble.writeCharacteristicWithResponse(_connectedChar!,
            value: bytes);
      } else {
        await _ble.writeCharacteristicWithoutResponse(_connectedChar!,
            value: bytes);
      }
    } catch (e) {
      if (kDebugMode) print('Erro ao escrever: $e');
      rethrow;
    }
  }

  Future<void> disconnect() async {
    _connected = false;
    _connectedChar = null;
    _deviceId = null;
    await _scanSub?.cancel();
    await _connectionSub?.cancel();
    notifyListeners();
  }
}
